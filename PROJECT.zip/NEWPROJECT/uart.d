uart.o: uart.c
uart.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
uart.o: uart.h
uart.o: types.h
