dot_main.o: dot_main.c
dot_main.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
dot_main.o: sipo_74hc164.h
dot_main.o: types.h
dot_main.o: types.h
