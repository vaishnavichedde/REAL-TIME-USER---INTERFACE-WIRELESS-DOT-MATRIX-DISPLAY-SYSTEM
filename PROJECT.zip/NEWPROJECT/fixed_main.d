fixed_main.o: fixed_main.c
fixed_main.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
fixed_main.o: fixed_string.h
fixed_main.o: types.h
fixed_main.o: sipo_74hc164.h
fixed_main.o: types.h
