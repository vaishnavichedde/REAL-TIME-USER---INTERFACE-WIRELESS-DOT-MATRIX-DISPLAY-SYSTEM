chexk.o: chexk.c
chexk.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
