hc_05_main.o: HC_05_main.c
hc_05_main.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
hc_05_main.o: fixed_string.h
hc_05_main.o: types.h
hc_05_main.o: uart.h
