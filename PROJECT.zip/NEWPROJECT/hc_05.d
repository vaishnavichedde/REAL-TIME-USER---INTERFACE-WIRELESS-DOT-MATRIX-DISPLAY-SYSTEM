hc_05.o: HC_05.c
hc_05.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
hc_05.o: fixed_string.h
hc_05.o: types.h
hc_05.o: defines.h
hc_05.o: delay.h
hc_05.o: types.h
